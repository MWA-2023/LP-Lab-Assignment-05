SimpleJspWebsite
================

This is a simple example of the JSP Java Website.


========== INTRODUCTION ==========

This is an example of a very simple Java/JSP website built with the Eclipse IDE.
It is compatible with the application server Tomcat.

Please copy the WAR file to TOMCAT_HOME/webapps/ and start your Tomcat server.


========== LICENSE ==========

Apache License, Version 2.0 or later; See the LICENSE.txt file.
