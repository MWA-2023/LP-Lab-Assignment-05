 /**
 * @author           Pierre-Henry Soria <pierrehenrysoria@gmail.com>
 * @link             http://github.com/pH-7
 * @copyright        Pierre-Henry Soria, All Rights Reserved.
 * @license          GNU General Public License version 3 or later. <http://www.gnu.org/copyleft/gpl.html>
 */

$('a[title],img[title]').tipsy({gravity:$.fn.tipsy.autoNS,fade:!0,html:!0});
